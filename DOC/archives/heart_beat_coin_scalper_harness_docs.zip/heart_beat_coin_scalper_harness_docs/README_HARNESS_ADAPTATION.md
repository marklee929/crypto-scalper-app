# Heart Beat Coin Scalper Harness Docs

이 산출물은 업로드된 `README.md`를 기준으로 기존 WorkConnect 하네스 문서 00~07을 `heart_beat_coin_scalper` 프로젝트용으로 재작성한 버전이다.

위치:

```text
DOC/architecture/00_PRODUCT_NORTH_STAR.md
DOC/architecture/01_SYSTEM_GROWTH_WORKFLOW.md
DOC/architecture/02_DATA_SOURCE_AND_QUALITY.md
DOC/architecture/03_SYSTEM_ARCHITECTURE.md
DOC/architecture/04_LOCAL_DEVELOPMENT_RUNTIME_GUIDE.md
DOC/architecture/05_CODEX_HARNESS_GUIDE.md
DOC/architecture/06_WORK_AREA_REGISTRY.md
DOC/architecture/07_HARNESS_RESTRUCTURE_REVIEW.md
```

중심 변경:

- WorkConnect 공개 게시물 보호 → Binance live order 보호
- 콘텐츠 품질 게이트 → 시장 데이터/캔들/전략 판단 품질 게이트
- Facebook publisher 보호 → Binance REST execution / config secret / live order 보호
- WorkConnect command → `!scalper-*` command
- `[WC_EXECUTION_COMPLETE]` → `[SCALPER_EXECUTION_COMPLETE]`
